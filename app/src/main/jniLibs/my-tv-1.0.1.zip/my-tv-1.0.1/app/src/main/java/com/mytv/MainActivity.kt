package com.github.mytv

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
import android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
import android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
import android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
import android.view.WindowManager
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.github.mytv.models.TVList
import com.github.mytv.models.TVViewModel
import com.github.mytv.speedtest.M3uParser
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch


class MainActivity : FragmentActivity(), OnSharedPreferenceChangeListener {

    private var ready = 0
    private val playerFragment = PlayerFragment()
    private val errorFragment = ErrorFragment()

    private val loadingFragment = LoadingFragment()
    private val mainFragment = MainFragment()
    private val infoFragment = InfoFragment()
    private val channelFragment = ChannelFragment()
    private var timeFragment = TimeFragment()
    private val settingFragment = SettingFragment()

    private var doubleBackToExitPressedOnce = false

    private lateinit var gestureDetector: GestureDetector

    private val handler = Handler()
    private val delayHideMain: Long = 10000
    private val delayHideSetting: Long = 15000

    fun syncTime() {
        lifecycleScope.launch(Dispatchers.IO) {
            val utilsJob = async(start = CoroutineStart.LAZY) { Utils.init() }
            utilsJob.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.setAttributes(lp)
        }

        window.decorView.apply {
            systemUiVisibility =
                SYSTEM_UI_FLAG_FULLSCREEN or
                        SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility =
            SYSTEM_UI_FLAG_FULLSCREEN or
                    SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            val transaction = supportFragmentManager.beginTransaction()
                .add(R.id.main_browse_fragment, playerFragment)
                .add(R.id.main_browse_fragment, errorFragment)
                .add(R.id.main_browse_fragment, loadingFragment)
                .add(R.id.main_browse_fragment, timeFragment)
                .add(R.id.main_browse_fragment, infoFragment)
                .add(R.id.main_browse_fragment, channelFragment)
                .add(R.id.main_browse_fragment, mainFragment)
                .hide(mainFragment)
                .hide(errorFragment)
                .hide(loadingFragment)

            if (!SP.time) {
                transaction.hide(timeFragment)
            } else {
                transaction.show(timeFragment)
            }

            transaction.commitNow()
        }
        gestureDetector = GestureDetector(this, GestureListener())

        SP.setOnSharedPreferenceChangeListener(this)

        // 加载本地频道列表
        TVList.load(this)

        // 首次安装（从未测过速）或用户开启了自动测速 → 弹出测速进度窗口
        val neverTested = SP.lastSpeedtest == 0L
        if (neverTested || SP.autoSpeedtest) {
            SpeedtestDialogFragment.show(this)
        }
    }

    fun showInfoFragment(tvViewModel: TVViewModel) {
        infoFragment.show(tvViewModel)
        if (SP.channelNum) {
            channelFragment.show(tvViewModel)
        }
    }

    fun showSourceIndicator(current: Int, total: Int) {
        infoFragment.showSourceIndicator(current, total)
    }

    fun showErrorFragment(msg: String) {
        errorFragment.show(msg)
        if (errorFragment.isVisible) {
            return
        }
        supportFragmentManager.beginTransaction()
            .show(errorFragment)
            .commit()
    }

    fun hideErrorFragment() {
        errorFragment.show("")
        if (!errorFragment.isVisible) {
            return
        }
        supportFragmentManager.beginTransaction()
            .hide(errorFragment)
            .commit()
    }

    fun showLoadingFragment() {
        showFragment(loadingFragment)
    }

    fun hideLoadingFragment() {
        hideFragment(loadingFragment)
    }

    fun showPlayerFragment() {
        if (playerFragment.isVisible) {
            return
        }
        supportFragmentManager.beginTransaction()
            .show(playerFragment)
            .commit()
    }

    fun hidePlayerFragment() {
        if (!playerFragment.isVisible) {
            return
        }
        supportFragmentManager.beginTransaction()
            .hide(playerFragment)
            .commit()
    }

    private fun showChannel(channel: String) {
        if (!mainFragment.isHidden) {
            return
        }

        if (settingFragment.isVisible) {
            return
        }

        if (SP.channelNum) {
            channelFragment.show(channel)
        }
    }

    fun play(tvViewModel: TVViewModel) {
        playerFragment.play(tvViewModel)
    }

    fun play(itemPosition: Int) {
        mainFragment.play(itemPosition)
    }

    fun prev() {
        mainFragment.prev()
    }

    fun next() {
        mainFragment.next()
    }

    fun switchMainFragment() {
        val transaction = supportFragmentManager.beginTransaction()

        if (mainFragment.isHidden) {
            mainFragment.setPosition()
            transaction.show(mainFragment)
            mainActive()
        } else {
            transaction.hide(mainFragment)
        }

        transaction.commit()
    }

    fun mainActive() {
        handler.removeCallbacks(hideMain)
        handler.postDelayed(hideMain, delayHideMain)
    }

    fun settingDelayHide() {
        handler.removeCallbacks(hideSetting)
        handler.postDelayed(hideSetting, delayHideSetting)
    }

    fun settingNeverHide() {
        handler.removeCallbacks(hideSetting)
    }

    private val hideMain = Runnable {
        if (!mainFragment.isHidden) {
            supportFragmentManager.beginTransaction().hide(mainFragment).commit()
        }
    }

    private fun mainFragmentIsHidden(): Boolean {
        return mainFragment.isHidden
    }

    private fun hideMainFragment() {
        if (!mainFragment.isHidden) {
            supportFragmentManager.beginTransaction()
                .hide(mainFragment)
                .commit()
        }
    }

    /**
     * 测速完成后调用：重新读取本地 m3u8 并刷新频道列表 UI。
     */
    fun reloadChannels() {
        TVList.load(this)
        mainFragment.buildChannelList()
        Toast.makeText(this, "频道列表已更新", Toast.LENGTH_SHORT).show()
    }

    fun fragmentReady(tag: String) {
        ready++
        Log.i(TAG, "ready $tag $ready ")
        // 共 7 个 fragment，用 >=7 触发
        if (ready >= 7) {
            mainFragment.fragmentReady()
        }
    }

    private fun showTime() {
        if (SP.time) {
            showFragment(timeFragment)
        } else {
            hideFragment(timeFragment)
        }
    }

    private fun showFragment(fragment: Fragment) {
        if (!fragment.isHidden) {
            return
        }

        supportFragmentManager.beginTransaction()
            .show(fragment)
            .commitNow()
    }

    private fun hideFragment(fragment: Fragment) {
        if (fragment.isHidden) {
            return
        }

        supportFragmentManager.beginTransaction()
            .hide(fragment)
            .commitNow()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event != null) {
            gestureDetector.onTouchEvent(event)
        }
        return super.onTouchEvent(event)
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            Log.i(TAG, "onSingleTapConfirmed")
            switchMainFragment()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            showSetting()
            return true
        }

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            if (velocityY > 0) {
                if (mainFragment.isHidden) {
                    prev()
                }
            }
            if (velocityY < 0) {
                if (mainFragment.isHidden) {
                    next()
                }
            }
            return super.onFling(e1, e2, velocityX, velocityY)
        }
    }

    private fun showSetting() {
        if (!mainFragment.isHidden) {
            return
        }

        if (settingFragment.isVisible) {
            return
        }

        settingFragment.show(supportFragmentManager, TAG)
        settingDelayHide()
    }

    private val hideSetting = Runnable {
        if (settingFragment.isVisible) {
            settingFragment.dismiss()
        }
    }

    private fun hideSettingFragment() {
        handler.postDelayed(hideSetting, 0)
    }

    private fun channelUp() {
        if (mainFragment.isHidden) {
            if (SP.channelReversal) {
                next()
                return
            }
            prev()
        }
    }

    private fun channelDown() {
        if (mainFragment.isHidden) {
            if (SP.channelReversal) {
                prev()
                return
            }
            next()
        }
    }

    private fun back() {
        if (!mainFragmentIsHidden()) {
            hideMainFragment()
            return
        }

        if (settingFragment.isVisible) {
            hideSettingFragment()
            return
        }

        if (doubleBackToExitPressedOnce) {
            super.onBackPressed()
            return
        }

        doubleBackToExitPressedOnce = true
        Toast.makeText(this, "再按一次退出", Toast.LENGTH_SHORT).show()

        Handler(Looper.getMainLooper()).postDelayed({
            doubleBackToExitPressedOnce = false
        }, 2000)
    }

    private fun active() {
        if (settingFragment.isVisible) {
            settingDelayHide()
        }
    }

    fun onKey(keyCode: Int): Boolean {
        Log.i(TAG, "keyCode $keyCode")
        when (keyCode) {
            KeyEvent.KEYCODE_0 -> { showChannel("0"); return true }
            KeyEvent.KEYCODE_1 -> { showChannel("1"); return true }
            KeyEvent.KEYCODE_2 -> { showChannel("2"); return true }
            KeyEvent.KEYCODE_3 -> { showChannel("3"); return true }
            KeyEvent.KEYCODE_4 -> { showChannel("4"); return true }
            KeyEvent.KEYCODE_5 -> { showChannel("5"); return true }
            KeyEvent.KEYCODE_6 -> { showChannel("6"); return true }
            KeyEvent.KEYCODE_7 -> { showChannel("7"); return true }
            KeyEvent.KEYCODE_8 -> { showChannel("8"); return true }
            KeyEvent.KEYCODE_9 -> { showChannel("9"); return true }

            KeyEvent.KEYCODE_ESCAPE,
            KeyEvent.KEYCODE_BACK -> { back(); return true }

            KeyEvent.KEYCODE_BOOKMARK,
            KeyEvent.KEYCODE_HELP,
            KeyEvent.KEYCODE_SETTINGS,
            KeyEvent.KEYCODE_MENU -> { showSetting(); return true }

            KeyEvent.KEYCODE_UNKNOWN -> return true

            KeyEvent.KEYCODE_ENTER -> { active(); switchMainFragment() }
            KeyEvent.KEYCODE_DPAD_CENTER -> { switchMainFragment() }
            KeyEvent.KEYCODE_DPAD_UP -> { active(); channelUp() }
            KeyEvent.KEYCODE_CHANNEL_UP -> { channelUp() }
            KeyEvent.KEYCODE_DPAD_DOWN -> { active(); channelDown() }
            KeyEvent.KEYCODE_CHANNEL_DOWN -> { channelDown() }

            KeyEvent.KEYCODE_DPAD_LEFT -> {
                active()
                if (mainFragment.isHidden && !settingFragment.isVisible) {
                    mainFragment.switchSource(-1)
                    return true
                }
            }

            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                active()
                if (mainFragment.isHidden && !settingFragment.isVisible) {
                    mainFragment.switchSource(+1)
                    return true
                }
            }
        }
        return false
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (onKey(keyCode)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        Log.i(TAG, "onStart MainActivity")
        syncTime()
        super.onStart()
    }

    override fun onResume() {
        Log.i(TAG, "onResume")
        super.onResume()
    }

    override fun onResumeFragments() {
        super.onResumeFragments()
        mainFragment.changeMenu()

        if (!mainFragment.isHidden) {
            handler.postDelayed(hideMain, delayHideMain)
        }
    }

    override fun onPause() {
        Log.i(TAG, "onPause")
        super.onPause()
        handler.removeCallbacks(hideMain)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private companion object {
        const val TAG = "MainActivity"
    }

    override fun onSharedPreferenceChanged(key: String) {
        Log.i(TAG, "$key changed")
        when (key) {
            SP.KEY_GRID -> mainFragment.changeMenu()
            SP.KEY_TIME -> showTime()
        }
    }
}
